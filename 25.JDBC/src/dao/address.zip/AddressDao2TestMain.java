package dao.address;

import java.util.ArrayList;

public class AddressDao2TestMain {

	public static void main(String[] args) throws Exception {
		AddressDao2 addressDao2= new AddressDao2();
		int result = addressDao2.insert("ttt","�����","2341-3119","LA");
		result = addressDao2.insert(new Address(0, "kkkk", "����Ƽ", "333-3434", "����ù�"));
		Address updateAddress = new Address(1, "guard", "�躯��", "333-2341", "���ù�");
		result = addressDao2.update(updateAddress);
//		result = addressDao2.delete(9);
//		Address address=addressDao2.selectByPk(5);
//		address=addressDao2.selectByPk(7);
//		address=addressDao2.selectByPk(1);
//		ArrayList<Address> addressList= addressDao2.selectAll();		
		

	}

}
