package dao.dept;

public class DeptSQL {

}
