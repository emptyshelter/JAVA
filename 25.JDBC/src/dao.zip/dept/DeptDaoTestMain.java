package dao.dept;

public class DeptDaoTestMain {

	public static void main(String[] args) {
	}

}
