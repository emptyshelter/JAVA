package dao.dept;

import java.util.List;

public class DeptDaoImpl implements DeptDao{

	@Override
	public void insert(Dept deparment) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Dept selectByNo(int deptno) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List selectByAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
